select
  *
from
  DUAL